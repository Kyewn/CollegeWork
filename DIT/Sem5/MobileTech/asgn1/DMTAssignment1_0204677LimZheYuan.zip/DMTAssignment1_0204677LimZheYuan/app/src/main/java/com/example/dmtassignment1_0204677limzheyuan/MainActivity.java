package com.example.dmtassignment1_0204677limzheyuan;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.InputMismatchException;

public class MainActivity extends AppCompatActivity {
    //Design views
    private EditText txtBill, txtPeople;
    private Button btnTip10, btnTip15, btnTip20, btnReset, btnCalculate, btnRound;
    private TextView lblBill, lblPeople, lblTotal, lblTip,lblResult, resTotal, resTip,resResult;
    //Global consts and vars
    private final double minBillAmount = 2;
    private int tipBtnSelected = -1;
    private double tipPerc = 0;

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        //save states before orientation change
        //values
        outState.putString("resResult", resResult.getText().toString());
        outState.putString("resTotal", resTotal.getText().toString());
        outState.putString("resTip", resTip.getText().toString());
        //selected buttons
        outState.putInt("tipBtnSelected", tipBtnSelected);
        //visibility
        outState.putInt("vis_lblResult", lblResult.getVisibility());
        outState.putInt("vis_lblTotal", lblTotal.getVisibility());
        outState.putInt("vis_lblTip", lblTip.getVisibility());
        outState.putInt("vis_resResult", resResult.getVisibility());
        outState.putInt("vis_resTotal", resTotal.getVisibility());
        outState.putInt("vis_resTip", resTip.getVisibility());
        outState.putInt("vis_btnRound", btnRound.getVisibility());
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        //Restore previous values before orientation change:
        //values
        resResult.setText(savedInstanceState.getString("resResult"));
        resTotal.setText(savedInstanceState.getString("resTotal"));
        resTip.setText(savedInstanceState.getString("resTip"));

        //selected buttons
        int savedBtnSelected = savedInstanceState.getInt("tipBtnSelected");
        //Set value of tip selected before orientation change
        //A.N. Everything can be restored because onRestoreInstanceState is called AFTER onCreate
        tipBtnSelected = savedBtnSelected;
        if (savedBtnSelected == 0) {
            tipPerc = 0.1;
            changeButtonColor("selected", btnTip10);
        } else if (savedBtnSelected == 1) {
            tipPerc = 0.15;
            changeButtonColor("selected", btnTip15);
        } else if (savedBtnSelected == 2) {
            tipPerc = 0.2;
            changeButtonColor("selected", btnTip20);
        } else {
            tipPerc = 0;
            deselectAllTipBtns();
        }

        //visibility
        lblResult.setVisibility(savedInstanceState.getInt("vis_lblResult"));
        lblTip.setVisibility(savedInstanceState.getInt("vis_lblTip"));
        lblTotal.setVisibility(savedInstanceState.getInt("vis_lblTotal"));
        resResult.setVisibility(savedInstanceState.getInt("vis_resResult"));
        resTip.setVisibility(savedInstanceState.getInt("vis_resTip"));
        resTotal.setVisibility(savedInstanceState.getInt("vis_resTotal"));
        btnRound.setVisibility(savedInstanceState.getInt("vis_btnRound"));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Set reference to design elements
        lblBill = findViewById(R.id.lblBill);
        lblPeople = findViewById(R.id.lblPeople);
        txtBill = findViewById(R.id.txtBill);
        txtPeople = findViewById(R.id.txtPeople);
        btnTip10 = findViewById(R.id.btnTip10);
        btnTip15 = findViewById(R.id.btnTip15);
        btnTip20 = findViewById(R.id.btnTip20);
        btnReset = findViewById(R.id.btnReset);
        btnCalculate = findViewById(R.id.btnCalculate);
        btnRound = findViewById(R.id.btnRound);
        lblTotal = findViewById(R.id.lblSummTotal);
        lblTip = findViewById(R.id.lblSummTip);
        lblResult = findViewById(R.id.lblSummResult);
        resTotal = findViewById(R.id.resTotal);
        resTip = findViewById(R.id.resTip);
        resResult = findViewById(R.id.resResult);

        //Set event listeners
        //Error recovery - restore label text colour if user reenters input in text fields after an error
        txtBill.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                changeControlColor("normal", lblBill, txtBill);
                return false;
            }
        });
        txtPeople.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                changeControlColor("normal", lblPeople, txtPeople);
                return false;
            }
        });

        //Set button event listeners
        btnTip10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //If it is already selected, deselect it
                if (tipBtnSelected == 0) {
                    changeButtonColor("deselected", btnTip10);
                    tipBtnSelected = -1;
                } else {
                    //Deselect any selected buttons
                    deselectAllTipBtns();
                    //Set bg and text color
                    changeButtonColor("selected", btnTip10);
                    //Set selected button value
                    tipBtnSelected = 0;
                }
            }
        });


        btnTip15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //If it is already selected, deselect it
                if (tipBtnSelected == 1) {
                    changeButtonColor("deselected", btnTip15);
                    tipBtnSelected = -1;
                } else {
                    //Deselect any selected buttons
                    deselectAllTipBtns();
                    //Set bg and text color
                    changeButtonColor("selected", btnTip15);
                    //Set selected button value
                    tipBtnSelected = 1;
                }
            }
        });

        btnTip20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //If it is already selected, deselect it
                if (tipBtnSelected == 2) {
                    changeButtonColor("deselected", btnTip20);
                    tipBtnSelected = -1;
                } else {
                    //Deselect any selected buttons
                    deselectAllTipBtns();
                    //Set bg and text color
                    changeButtonColor("selected", btnTip20);
                    //Set selected button value
                    tipBtnSelected = 2;
                }
            }
        });

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Reset controls
                deselectAllTipBtns();
                changeControlColor("normal", lblBill, txtBill);
                changeControlColor("normal", lblPeople, txtPeople);
                txtBill.setText("");
                txtPeople.setText("");
                //Hide details
                setSummaryVisible(false);
            }
        });

        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    //Declare result containers
                    double tipAmount, splitTotal;
                    //Get inputs
                    double billAmount = Double.parseDouble(txtBill.getText().toString());
                    int noOfPeople = Integer.parseInt(txtPeople.getText().toString());
                    //Input validation
                    //  Bill amount
                    if (billAmount < minBillAmount) throw new InputMismatchException();
                    //  No of people
                    if (noOfPeople < 2) throw new InputMismatchException();

                    //Get selected button
                    if (tipBtnSelected == 0)
                        tipPerc = 0.1;
                    else if (tipBtnSelected == 1)
                        tipPerc = 0.15;
                    else if (tipBtnSelected == 2)
                        tipPerc = 0.2;
                    else {
                        tipPerc = 0;
                    }

                    //Process values
                    splitTotal = billAmount / noOfPeople;
                    tipAmount = billAmount * tipPerc;

                    //Assign values to output before turning them visible
                    resResult.setText(getString(R.string.billResult, splitTotal));
                    resTip.setText(getString(R.string.billResult, tipAmount));
                    resTotal.setText(getString(R.string.billResult, billAmount));
                    setSummaryVisible(true);
                } catch (InputMismatchException ime) {
                    //Two possible error case:
                    //  -Bill amount < min. bill amount
                    //  -No of people < 2
                    double billAmount = Double.parseDouble(txtBill.getText().toString());
                    int noOfPeople = Integer.parseInt(txtPeople.getText().toString());

                    if (billAmount < minBillAmount) {
                        //throw error when bill amount < 2 because value too tiny for calculation
                        Toast.makeText(getApplicationContext(), "Minimum bill amount: 2!", Toast.LENGTH_SHORT).show();
                        changeControlColor("error", lblBill, txtBill);
                        txtBill.requestFocus();
                    } else if (noOfPeople < 2) {
                        //throw error when no. of people < 2 to avoid arithmetic error
                        Toast.makeText(getApplicationContext(), "Minimum person count: 2!", Toast.LENGTH_SHORT).show();
                        changeControlColor("error", lblPeople, txtPeople);
                        txtPeople.requestFocus();
                    }
                } catch (Exception e) {
                    //throw error when input is empty
                    Toast.makeText(getApplicationContext(), "Please fill in all text fields!", Toast.LENGTH_SHORT).show();
                    //Highlight empty inputs
                    if (txtPeople.getText().toString().equals("")) {
                        changeControlColor("error", lblPeople, txtPeople);
                        txtPeople.requestFocus();
                    }
                    if (txtBill.getText().toString().equals("")) {
                        changeControlColor("error", lblBill, txtBill);
                        txtBill.requestFocus();
                    }
                }
            }
        });

        btnRound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Declare vars
                double newSplitTotal, total, roundedTotal, newTip;
                int noOfPeople;
                //Get value after '$' sign
                total = Double.parseDouble(resTotal.getText().toString().substring(1));
                noOfPeople = Integer.parseInt(txtPeople.getText().toString());

                //Round the total and calculate new split total and tip
                roundedTotal = Math.round(total);
                newSplitTotal = roundedTotal / noOfPeople;
                newTip = roundedTotal * tipPerc;
                //Set round values to labels
                resTotal.setText(getString(R.string.billResult, roundedTotal));
                resResult.setText(getString(R.string.billResult, newSplitTotal));
                resTip.setText(getString(R.string.billResult, newTip));
                //Hide button
                btnRound.setVisibility(View.GONE);
            }
        });
    }

    private void setSummaryVisible(boolean visible) {
        if (visible) {
            //Set everything visible
            lblResult.setVisibility(View.VISIBLE);
            lblTip.setVisibility(View.VISIBLE);
            lblTotal.setVisibility(View.VISIBLE);
            resResult.setVisibility(View.VISIBLE);
            resTip.setVisibility(View.VISIBLE);
            resTotal.setVisibility(View.VISIBLE);
            btnRound.setVisibility(View.VISIBLE);
        } else {
            //Set everything invisible
            lblResult.setVisibility(View.GONE);
            lblTip.setVisibility(View.GONE);
            lblTotal.setVisibility(View.GONE);
            resResult.setVisibility(View.GONE);
            resTip.setVisibility(View.GONE);
            resTotal.setVisibility(View.GONE);
            btnRound.setVisibility(View.GONE);
        }
    }

    private void changeButtonColor(String state, Button btn) {
        if (state.equals("selected")) {
            //Set bg green and text white
            btn.setBackgroundTintList(getColorStateList(R.color.greenClr));
            btn.setTextColor(getColorStateList(R.color.white));
        } else if (state.equals("deselected")) {
            //Set text green and bg white
            btn.setBackgroundTintList(getColorStateList(R.color.white));
            btn.setTextColor(getColorStateList(R.color.greenClr));
        }
    }

    private void changeControlColor(String state, TextView lbl, EditText input) {
        if (state.equals("normal")) {
            //Set default color - lbl black and input green
            lbl.setTextColor(Color.BLACK);
            input.setBackgroundTintList(getColorStateList(R.color.greenClr));
        } else if (state.equals("error")) {
            //Set both lbl and input color red
            lbl.setTextColor(getColorStateList(R.color.errorClr));
            input.setBackgroundTintList(getColorStateList(R.color.errorClr));
        }
    }

    private void deselectAllTipBtns() {
        //Set bg colour
        //Set text colour
        //btnTip10
        btnTip10.setBackgroundTintList(getColorStateList(R.color.white));
        btnTip10.setTextColor(getColorStateList(R.color.greenClr));
        //btnTip15
        btnTip15.setBackgroundTintList(getColorStateList(R.color.white));
        btnTip15.setTextColor(getColorStateList(R.color.greenClr));
        //btnTip20
        btnTip20.setBackgroundTintList(getColorStateList(R.color.white));
        btnTip20.setTextColor(getColorStateList(R.color.greenClr));
        //Set selected value to -1
        tipBtnSelected = -1;
    }
}