import numpy
import matplotlib.pyplot
import pandas
pandas.set_option('display.max_rows', None)
dataset = pandas.read_csv("HatchData.csv")
dataset.drop(dataset.columns[[0,1,4,5,8,9,10]], axis=1, inplace=True)
dataset.rename(columns = {'Message_Temp.1' : 'Message_Humid'}, inplace=True)
df = dataset.sort_values(by=['Humidity_Data'], ascending=True)
print(df.iloc[1000:2000])