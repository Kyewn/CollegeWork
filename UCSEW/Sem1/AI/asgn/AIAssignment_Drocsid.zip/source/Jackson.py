import numpy #Import NumPy Library
import pandas  #Import Pandas Library

#Online Json Libraries
import json
import urllib.request
from urllib.request import urlopen

#Fuzzy Logic Libraries
import skfuzzy
from skfuzzy import control

#Decision Tree Libraries
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

#Discord Libraries
import os
import discord
from discord.ext import commands
from dotenv import load_dotenv

#NLP Libraries
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer

nltk.download('stopwords') #Download the stopwords



'''CSV Section'''
#Collecting and modifying the HatchData.csv
hatchData = pandas.read_csv("HatchData.csv")
hatchData.drop(hatchData.columns[[0,1,4,5,8,9,10]], axis=1, inplace=True)
hatchData.rename(columns = {'Message_Temp.1' : 'Message_Humid'}, inplace=True)

#Add a 'success' column
success = [0] * 3610
for i in range(3610):
    #Success if it is both Moderate and Well, otherwise it is a fail
    if hatchData.iloc[i]['Message_Temp'] == 'Moderate' and hatchData.iloc[i]['Message_Humid'] == 'Well':
        success[i] = 1
    else:
        success[i] = 0
hatchData['Success'] = success



'''JSON File Section'''
#Retriving the online Json file via URL
url = "https://eggincubator-825e1-default-rtdb.firebaseio.com/.json"
response = urlopen(url)
jsonData = json.loads(response.read())

#Variables collected from the Json file
bulb_times = jsonData["Bulb on times:"]
bulb = jsonData["BulbStatus"]
day = jsonData["Day"]
fan = jsonData["FanStatus"]
humid_data = jsonData["Humidity"]
humid_data_array = list(jsonData['Humidity_Data'].values())
temp_data = jsonData["Temperature"]
temp_data_array = list(jsonData['Temperature_Data'].values())
valve = jsonData["ValveStatus"]



'''Fuzzy Logic Section'''
#Setting up the antecedent and consequent.
temp_fuzz = control.Antecedent(numpy.arange(27, 48.5, 0.5), 'Temperature (Celcius)')
humid_fuzz = control.Antecedent(numpy.arange(15, 126.5, 0.5), 'Humidity (%)')
incubation = control.Consequent(numpy.arange(-50, 150, 0.5), 'Incubation Yield (%)')

#Temperature Fuzzy Logic
temp_fuzz['Too Cold'] = skfuzzy.trapmf(temp_fuzz.universe, [26,26,29,35])
temp_fuzz['Moderate'] = skfuzzy.trimf(temp_fuzz.universe, [31,37.5,44])
temp_fuzz['Too Hot'] = skfuzzy.trapmf(temp_fuzz.universe, [40,46,49,49])

#Humidity Fuzzy Logic
humid_fuzz['Too Dry'] = skfuzzy.trapmf(humid_fuzz.universe, [14,14,29,58])
humid_fuzz['Well'] = skfuzzy.trimf(humid_fuzz.universe, [39,70.5,102])
humid_fuzz['Too Humid'] = skfuzzy.trapmf(humid_fuzz.universe, [82,112,127,127])

#Incubation Fuzzy Logic
incubation['Failure'] = skfuzzy.trapmf(incubation.universe, [-50,-50,10,90])
incubation['Success'] = skfuzzy.trapmf(incubation.universe, [10,90,150,150])

#Setting up the rules
rule1 = control.Rule(temp_fuzz['Moderate'] & humid_fuzz['Well'], incubation['Success'])
rule2 = control.Rule(temp_fuzz['Too Cold'] | temp_fuzz['Too Hot'] | humid_fuzz['Too Dry'] | humid_fuzz['Too Humid'], incubation['Failure'])
incu_yield = control.ControlSystemSimulation(control.ControlSystem([rule1,rule2]))



'''Decision Tree Section'''
#Setting up the 'test and train' procedure
x = hatchData[['Temperature_Data', 'Humidity_Data']].values
y = hatchData['Success'].values
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.3, random_state = 0)

#Train the Decision Tree
hatchDT = DecisionTreeClassifier(criterion='gini', random_state=0)
hatchDT.fit(x_train, y_train)



'''Discord Section'''
#Getting the bot's token in order to code via Python
load_dotenv()
token = os.getenv("TOKEN")
bot = commands.Bot(command_prefix='!', intents=discord.Intents.all()) #Loading the bot into Discord

#Checking the bot is online
@bot.event
async def on_ready():
    print("Logged in as a bot {0.user}".format(bot))

@bot.event
async def on_message(message):
    #Getting the message from the users
    username = str(message.author).split("#")[0]
    user_message = str(message.content)
    channel = str(message.channel.name)
    print(f"{username}: {user_message} ({channel})")
    if message.author == bot.user:
        return

    #Bot commands in #test-bot channel
    if message.channel.name == "test-bot":
        #Reprocess the message
        keywords = re.sub('[^a-zA-Z]',' ', user_message)
        keywords = keywords.lower()
        keywords = keywords.split()
        ps = PorterStemmer()
        all_stopwords = stopwords.words('english')
        all_stopwords.remove('not')
        keywords = [ps.stem(word) for word in keywords if not word in set(all_stopwords)]
        keywords = ' '.join(keywords)
        keywords = keywords + " "
        '''text_repro = discord.Embed(title="Text Reprocessing", color=0xadd8e6)
        text_repro.add_field(name="Original Message:", value=user_message, inline=False)
        text_repro.add_field(name="Reprocessed Message:", value=keywords, inline=False)
        await message.channel.send(embed=text_repro)'''

        #Says hi to the user
        if ("hello " in keywords or "hi " in keywords) and "jackson " in keywords:
            await message.channel.send(f"Hello, {username}. :wave:")
            return

        #Respond to user Jackson is online
        if "onlin " in keywords and "jackson " in keywords:
            await message.channel.send("Yes, I am still online.")
            return

        #Listing out all of the commands
        if ("function " in keywords or "help " in keywords) and "jackson " in keywords:
            command = discord.Embed(title=f"{username}, here's what I can do: ", description=":page_with_curl: I can read the data from the live incubation JSON.\n\n:chart_with_upwards_trend: I can generate a report based on current incubation conditions.\n\n:clock10: I can show you the histories of temperature and humidity data.\n\n:robot: I can predict the success of your incubation.", color=0x0000ff)
            await message.channel.send(embed=command)
            return

        #Takes the json data and prints into more human friendly format
        if "json " in keywords and "jackson " in keywords:
            json_report = discord.Embed(title="Sure, here it is:", description=f":bulb: Bulb on times: {bulb_times}\n:bulb: Bulb status: {bulb}\n:date: Day: {day}\n:wind_chime: Fan Status: {fan}\n:droplet: Humidity: {humid_data}\n:thermometer: Temperature: {temp_data}\n:nut_and_bolt: Valve Status: {valve}", color=0x0000ff)
            await message.channel.send(embed=json_report)
            return

        #List the temperatures history
        if "temperatur " in keywords and "histori " in keywords and "jackson " in keywords:
            temp_history = discord.Embed(title=":thermometer: Here are the last 10 updates on Temperature Data:", description=f"{temp_data_array[-10]} (Oldest)\n{temp_data_array[-9]}\n{temp_data_array[-8]}\n{temp_data_array[-7]}\n{temp_data_array[-6]}\n{temp_data_array[-5]}\n{temp_data_array[-4]}\n{temp_data_array[-3]}\n{temp_data_array[-2]}\n{temp_data_array[-1]} (Newest)", color=0x0000ff)
            await message.channel.send(embed=temp_history)
            return

        #List the humidities history
        if "humid " in keywords and "histori " in keywords and "jackson " in keywords:
            humid_history = discord.Embed(title=":droplet: Here are the last 10 updates on Humidity Data:", description=f"{humid_data_array[-10]} (Oldest)\n{humid_data_array[-9]}\n{humid_data_array[-8]}\n{humid_data_array[-7]}\n{humid_data_array[-6]}\n{humid_data_array[-5]}\n{humid_data_array[-4]}\n{humid_data_array[-3]}\n{humid_data_array[-2]}\n{humid_data_array[-1]} (Newest)", color=0x0000ff)
            await message.channel.send(embed=humid_history)
            return
        
        if "predict " in keywords and "jackson " in keywords:
            await message.channel.send("Okay, just use the **!predict** command to do that!\n\nTry typing `!predict <temperature_value> <humidity_value>`.")
            return

        #Checking the success rate of the incubation
        if ("success " in keywords or "yie " in keywords or "report " in keywords) and "incub " in keywords and "jackson " in keywords:
            
            #Produce the report
            incu_yield.input['Temperature (Celcius)'] = temp_data
            incu_yield.input['Humidity (%)'] = humid_data
            incu_yield.compute()
            yield_report = discord.Embed(title=f":clipboard: Here is the report for the current incubation, {username}:", description=f":thermometer: Temperature: {temp_data}\n:droplet: Humidity: {humid_data}\n\n:white_check_mark: Success Rate: {incu_yield.output['Incubation Yield (%)']:.2f} %", color=0x0000ff)

            #Judging the temperature of the incubation
            if temp_data < 34: #If Temperature is too cold
                temp_message = "The environment is too cold, you might need to heat the egg up a bit or check whether your thermometer is calibrated correctly."
            elif temp_data >= 41: #If Temperature is too hot
                temp_message = "The environment is too hot, you might need to cool the egg down a bit or check whether your thermometer is calibrated correctly."
            else:
                temp_message = "Doing fine so far."
            yield_report.add_field(name="Temperature Analysis:", value=temp_message, inline=False)

            #Judging the humidity of the incubation
            if humid_data < 50: #If Humidity is too dry
                humid_message = "The environment is too dry, you might need to add water to the water trough or check whether your hygrometer is working properly."
            elif humid_data >= 91: #If Humidity is too humid
                humid_message = "The environment is too humid, you might need to use an absorptive material to absorb some excess water or check whether your hygrometer is working properly."
            else:
                humid_message = "Doing fine so far."
            yield_report.add_field(name="Humidity Analysis:", value=humid_message, inline=False)

            await message.channel.send(embed=yield_report)
            return

        await bot.process_commands(message) #This allows the bot to use commands during the on_message event

#Predict Command
@bot.command()
async def predict(ctx,tempStr,humidStr):
    try:
        #Convent the inputs into float
        tempFlo = float(tempStr)
        humidFlo = float(humidStr)

        pred = hatchDT.predict([[tempFlo,humidFlo]]) #Predict the data using the inputs

        if pred[0] == 0: #If the prediction results in failed incubation
            await ctx.send(":x: I predict that the incubation will not be successful.")
        elif pred[0] == 1: #If the prediction results in successful incubation
            await ctx.send(":white_check_mark: I predict that the incubation will be successful.")
    except: #If the Temperature and Humid is not float
        await ctx.send("Invalid input") #Send error message


bot.run(token) #Run the bot