package com.example.week4cet3013labbkgroupjan2022;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {
    private Button discount_button;
    private EditText last_name, first_name, email;
    private TextView discount_confirmation, discount_code;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //set the references to the GUI elements
        discount_button         = findViewById(R.id.discount_button);
        last_name               = findViewById(R.id.last_name);
        first_name              = findViewById(R.id.first_name);
        email                   = findViewById(R.id.email);
        discount_confirmation   = findViewById(R.id.discount_confirmation);
        discount_code           = findViewById(R.id.discount_code);

        //set the click listenr for the button
        discount_button.setOnClickListener(view -> {
            //Get the user inputs
            String first = first_name.getText().toString().trim();
            String last = last_name.getText().toString().trim();
            String email_address = email.getText().toString().trim();

            //perform simple validation
            if (first.isEmpty() || last.isEmpty() || email_address.isEmpty()) {
                //get the validation message (error message)
                String errorMsg = MainActivity.this.getString(R.string.add_text_validation);
                Toast.makeText(MainActivity.this, errorMsg, Toast.LENGTH_SHORT).show();
            } else {
                String full_name = first + " " + last;
                String confirmMessage = getString(R.string.discount_code_confirmation,full_name);

                String discount = UUID.randomUUID().toString().substring(0,8).toUpperCase();

                //display to the user
                discount_confirmation.setText(confirmMessage);
                discount_code.setText(discount);

                clearInputFields();
                hideKeyboard();
            }
        });

    }//onCreate


    private void hideKeyboard() {
        View view = this.getCurrentFocus();

        if (view != null) {
            // now assign the system
            // service to InputMethodManager
            InputMethodManager manager  = (InputMethodManager)
                    getSystemService(Context.INPUT_METHOD_SERVICE);
            manager.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    private void clearInputFields() {
        first_name.getText().clear();
        last_name.getText().clear();
        email.getText().clear();
    }

}